const { createClient } = require("@supabase/supabase-js");
const ytdl = require("ytdl-core");
const { v4: uuidv4 } = require("uuid");

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

const handler = async (event) => {
  const body = JSON.parse(event.body);
  const { url, pathPrefix } = body;

  if (!url || !pathPrefix) {
    const response = {
      statusCode: 400,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        successful: false,
        error: {
          message: "Bad request. Missing required parameters",
        },
      }),
    };
    return response;
  }

  try {
    if (!ytdl.validateURL(url)) {
      throw new Error("Invalid YouTube URL");
    }

    const uuid = uuidv4();
    const path = `${pathPrefix}-${uuid}.mp4`;

    const options = {
      quality: "highestaudio",
    };

    const stream = ytdl(url, options);

    const { data, error } = await supabase.storage
      .from("translation")
      .upload(path, stream, {
        contentType: "video/mp4",
      });

    if (error) {
      console.error("Upload error:", error);
      return;
    }

    if (!data) {
      console.error("No data returned from upload");
      return;
    }

    console.log("data: ", data);

    const url = `${process.env.NEXT_PUBLIC_SUPABASE_URL}/storage/v1/object/public/translation/${data.path}`;

    const response = {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        successful: true,
        data: {
          url,
        },
      }),
    };
    return response;
  } catch (error) {
    const response = {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
      },
      body: JSON.stringify({
        successful: false,
        error: {
          message: `Failed to upload youtube video to Supabase storage. - ${error.message}`,
        },
      }),
    };
    return response;
  }
};

module.exports.handler = handler;
